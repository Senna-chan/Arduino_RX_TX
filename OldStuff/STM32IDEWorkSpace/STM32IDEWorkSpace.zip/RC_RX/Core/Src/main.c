/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dac.h"
#include "i2c.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include "nrf24.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
channelOutputConfig channelsOutputConfig[24];
uint8_t nrfAddress[] = { 0x11, 0x22,0x33};
uint8_t nRFDataReady = 0;
uint8_t gotData = 0;
typedef struct
{
	// No bits free
	uint64_t identifier : 4;
	uint64_t channel1 : 10;
	uint64_t channel2 : 10;
	uint64_t channel3 : 10;
	uint64_t channel4 : 10;
	uint64_t channel5 : 10;
	uint64_t channel6 : 10;

	// 4 bits free
	uint64_t channel7 : 10;
	uint64_t channel8 : 10;
	uint64_t channel9 : 10;
	uint64_t channel10 : 10;
	uint64_t channel11 : 10;
	uint64_t channel12 : 10;

	// 4 bits free
	uint64_t channel13 : 10;
	uint64_t channel14 : 10;
	uint64_t channel15 : 10;
	uint64_t channel16 : 10;
	uint64_t channel17 : 10;
	uint64_t channel18 : 10;

	// 4 bits free
	uint64_t channel19 : 10;
	uint64_t channel20 : 10;
	uint64_t channel21 : 10;
	uint64_t channel22 : 10;
	uint64_t channel23 : 10;
	uint64_t channel24 : 10;

} channelBitSettings;

union channelDataU{
	uint8_t bytes[32];
	channelBitSettings chdat;
} channelData;

uint16_t channelValues[24];


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void __io_putchar(uint8_t ch) {
	HAL_UART_Transmit(&huart1, &ch, 1, 1);
}

void setErrorLed(uint8_t state){
	if(state){
		HAL_GPIO_WritePin(SLEDR_GPIO_Port, SLEDR_Pin, GPIO_PIN_SET);
	} else{
		HAL_GPIO_WritePin(SLEDR_GPIO_Port, SLEDR_Pin, GPIO_PIN_RESET);
	}
}

void setOkLed(uint8_t state){
	if(state){
		HAL_GPIO_WritePin(SLEDG_GPIO_Port, SLEDG_Pin, GPIO_PIN_SET);
	} else{
		HAL_GPIO_WritePin(SLEDG_GPIO_Port, SLEDG_Pin, GPIO_PIN_RESET);
	}
}

void setBlueLed(uint8_t state){
	if(state){
		HAL_GPIO_WritePin(SLEDB_GPIO_Port, SLEDB_Pin, GPIO_PIN_SET);
	} else{
		HAL_GPIO_WritePin(SLEDB_GPIO_Port, SLEDB_Pin, GPIO_PIN_RESET);
	}
}

void setStatusLed(uint8_t R, uint8_t G, uint8_t B){
	setErrorLed(R);
	setOkLed(G);
	setBlueLed(B);
}



void common_nRFInit() {
	nRF24_CE_L();
	delay(5);
	if (!nRF24_Check()) {
		UART_SendStr("NRF Module not found");
		Error_Handler();
	}

	nRF24_Init();

	// Set RF channel
	nRF24_SetRFChannel(40);

	// Set data rate
	nRF24_SetDataRate(nRF24_DR_1Mbps);

	// Set CRC scheme
	nRF24_SetCRCScheme(nRF24_CRC_2byte);

	// Set address width, its common for all pipes (RX and TX)
	nRF24_SetAddrWidth(3);

	// Configure RX PIPE
	if (!isTransmitter) {
		nRF24_SetAddr(nRF24_PIPE0, nrfAddress); 	// Set RX Pipe
	}
	else {
		nRF24_SetAddr(nRF24_PIPE0, nrfAddress); 	// Set RX Pipe
		nRF24_SetAddr(nRF24_PIPETX, nrfAddress);   // Set TX Pipe
		nRF24_SetAutoRetr(nRF24_ARD_250us, 10);
	}
	nRF24_SetRXPipe(nRF24_PIPE0, nRF24_AA_ON, 32); // Auto-ACK: enabled, payload length: 32 bytes

	// Set TX power
	nRF24_SetTXPower(nRF24_TXPWR_0dBm);

	// Enable DPL
	nRF24_SetDynamicPayloadLength(nRF24_DPL_ON);

	nRF24_SetPayloadWithAck(1);


	// Enable Auto-ACK for pipe#0 (for ACK packets)
	nRF24_EnableAA(nRF24_PIPE0);

	if (!isTransmitter) {
		// Set operational mode (PRX == receiver)
		nRF24_SetOperationalMode(nRF24_MODE_RX);
	}
	else {
		nRF24_SetAutoRetr(nRF24_ARD_250us, 3);


		nRF24_SetOperationalMode(nRF24_MODE_TX);
	}
	// Clear any pending IRQ flags
	nRF24_ClearIRQFlags();

	// Wake the transceiver
	nRF24_SetPowerMode(nRF24_PWR_UP);


	//nRF24_DumpConfig();
	if (!isTransmitter) {
		// Put the transceiver to the RX mode
		nRF24_CE_H();
	}
}

void UART_SendChar(char b) {
    HAL_UART_Transmit(&huart1, (uint8_t *) &b, 1, 200);
}

void UART_SendStr(char *string) {
    HAL_UART_Transmit(&huart1, (uint8_t *) string, (uint16_t) strlen(string), 200);
}

void setOutput(uint8_t index, uint16_t channelValue){
	channelOutputConfig choc = channelsOutputConfig[index];
	channelValue += 1000;
	channelValues[index] = channelValue;
	if(channelValue == 1001) {
		channelValues[index] = 0;
		return;
	}
	if(choc.outputMode == OUTPUTMODE_RC){
		*choc.timOutput = channelValue;
	}
}

void parseRFPacket(uint8_t* buf, uint8_t length){
	if(length == 6){
		for (int i = 0; i < length; i++) {
			printf(" %02d ", buf[i]);
		}
		UART_SendChar('\n');
	} else {
		memmove(channelData.bytes, buf, 32);
		setOutput(0 ,channelData.chdat.channel1 );
		setOutput(1 ,channelData.chdat.channel2 );
		setOutput(2 ,channelData.chdat.channel3 );
		setOutput(3 ,channelData.chdat.channel4 );
		setOutput(4 ,channelData.chdat.channel5 );
		setOutput(5 ,channelData.chdat.channel6 );
		setOutput(6 ,channelData.chdat.channel7 );
		setOutput(7 ,channelData.chdat.channel8 );
		setOutput(8 ,channelData.chdat.channel9 );
		setOutput(9 ,channelData.chdat.channel10);
		setOutput(10,channelData.chdat.channel11);
		setOutput(11,channelData.chdat.channel12);
		setOutput(12,channelData.chdat.channel13);
		setOutput(13,channelData.chdat.channel14);
		setOutput(14,channelData.chdat.channel15);
		setOutput(15,channelData.chdat.channel16);
		setOutput(16,channelData.chdat.channel17);
		setOutput(17,channelData.chdat.channel18);
		setOutput(18,channelData.chdat.channel19);
		setOutput(19,channelData.chdat.channel20);
		setOutput(20,channelData.chdat.channel21);
		setOutput(21,channelData.chdat.channel22);
		setOutput(22,channelData.chdat.channel23);
		setOutput(23,channelData.chdat.channel24);
	}
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DAC_Init();
  MX_ADC1_Init();
  MX_SPI2_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  MX_TIM5_Init();
  MX_UART4_Init();
  MX_UART5_Init();
  MX_USART1_UART_Init();
  MX_TIM1_Init();
  MX_TIM8_Init();
  MX_I2C1_Init();
  MX_USB_PCD_Init();
  /* USER CODE BEGIN 2 */
  MX_USB_DEVICE_Init();
  setBlueLed(1);

  printf("Starting RC Receiver\r\n");

  common_nRFInit();

  setBlueLed(0);
  printf("Started RC Receiver\r\n");
  uint32_t lastDataReceived = HAL_GetTick();

  uint8_t buf[32];
  uint8_t length = 0;

  channelsOutputConfig[0] .timOutput = &htim5.Instance->CCR1;
  channelsOutputConfig[1] .timOutput = &htim5.Instance->CCR2;
  channelsOutputConfig[2] .timOutput = &htim5.Instance->CCR3;
  channelsOutputConfig[3 ].timOutput = &htim5.Instance->CCR4;
  channelsOutputConfig[4 ].timOutput = &htim3.Instance->CCR1;
  channelsOutputConfig[5 ].timOutput = &htim3.Instance->CCR2;
  channelsOutputConfig[6 ].timOutput = &htim3.Instance->CCR3;
  channelsOutputConfig[7 ].timOutput = &htim3.Instance->CCR4;
  channelsOutputConfig[8 ].timOutput = &htim2.Instance->CCR3;
  channelsOutputConfig[9 ].timOutput = &htim2.Instance->CCR4;
  channelsOutputConfig[10].timOutput = &htim8.Instance->CCR1;
  channelsOutputConfig[11].timOutput = &htim8.Instance->CCR2;
  channelsOutputConfig[12].timOutput = &htim8.Instance->CCR3;
  channelsOutputConfig[13].timOutput = &htim8.Instance->CCR4;
  channelsOutputConfig[14].timOutput = &htim1.Instance->CCR1;
  channelsOutputConfig[15].timOutput = &htim2.Instance->CCR1;
  channelsOutputConfig[16].timOutput = &htim4.Instance->CCR1;
  channelsOutputConfig[17].timOutput = &htim4.Instance->CCR2;

//  nRF24_RXResult pipeLine = nRF24_ReadPayloadDpl(buf, &length);
//  while(!gotData){
//	  HAL_GPIO_TogglePin(SLEDB_GPIO_Port, SLEDB_Pin);
//	  HAL_Delay(250);
//  }

  // Requesting config here and checking that

//  setOkLed(1);
//  HAL_Delay(500);
//  setOkLed(0);

  HAL_TIM_Base_Start(&htim1);
  HAL_TIM_Base_Start(&htim2);
  HAL_TIM_Base_Start(&htim3);
  HAL_TIM_Base_Start(&htim4);
  HAL_TIM_Base_Start(&htim5);
  HAL_TIM_Base_Start(&htim8);
  HAL_TIM_PWM_Start(&htim5,1);
  HAL_TIM_PWM_Start(&htim5,2);
  HAL_TIM_PWM_Start(&htim5,3);
  HAL_TIM_PWM_Start(&htim5,4);
  HAL_TIM_PWM_Start(&htim3,1);
  HAL_TIM_PWM_Start(&htim3,2);
  HAL_TIM_PWM_Start(&htim3,3);
  HAL_TIM_PWM_Start(&htim3,4);
  HAL_TIM_PWM_Start(&htim2,3);
  HAL_TIM_PWM_Start(&htim2,4);
  HAL_TIM_PWM_Start(&htim8,1);
  HAL_TIM_PWM_Start(&htim8,2);
  HAL_TIM_PWM_Start(&htim8,3);
  HAL_TIM_PWM_Start(&htim8,4);
  HAL_TIM_PWM_Start(&htim1,1);
  HAL_TIM_PWM_Start(&htim2,1);
  HAL_TIM_PWM_Start(&htim4,1);
  HAL_TIM_PWM_Start(&htim4,2);


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  uint32_t lastCHPrint = HAL_GetTick();
  while (1)
  {
	  if (gotData) {
		  lastDataReceived = HAL_GetTick();
		  setStatusLed(0,1,0);
		  gotData = 0;

		  nRF24_RXResult pipeLine = nRF24_ReadPayloadDpl(buf, &length);
		  //printf("%s Message size '%d'. Data: ", isTransmitter ? "ACK" : "Message", length);
		  parseRFPacket(buf, length);

		  uint32_t now = HAL_GetTick();
		  if (!isTransmitter){
			  uint8_t txBuf[32];
			  txBuf[0] = 0;
			  txBuf[1] = 0;
			  txBuf[2] = now >> 24 & 0xFF;
			  txBuf[3] = now >> 16 & 0xFF;
			  txBuf[4] = now >> 8 & 0xFF;
			  txBuf[5] = now >> 0 & 0xFF;
			  nRF24_WriteAckPayload(pipeLine, (char*)txBuf,6);
		  }
	  }
	  if(HAL_GetTick() - lastDataReceived > 3000){
		  	setStatusLed(1,0,0);
	  } else if(HAL_GetTick() - lastDataReceived > 1500){
		  	setStatusLed(0,0,1);
	  }
	  if(HAL_GetTick() - lastCHPrint > 1000){
		  lastCHPrint = HAL_GetTick();
		  for(int i = 0;  i < 12; i++){
			  printf("CH%02d: %04d ",i+1, channelValues[i]);
		  }
		  printf("\r\n");
	  }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC|RCC_PERIPHCLK_USB;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV6;
  PeriphClkInit.UsbClockSelection = RCC_USBCLKSOURCE_PLL_DIV1_5;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin){
	if(GPIO_Pin == nRF_IRQ_Pin){
		uint8_t tx, fail, rx;
		uint8_t status = nRF24_GetIRQFlags();
		tx = (status & nRF24_FLAG_TX_DS) != 0;
		fail = (status & nRF24_FLAG_MAX_RT) != 0;
		rx = (status& nRF24_FLAG_RX_DR) != 0;
//		printf("T%dF%dR%d\r\n",tx,fail,rx);

		if (tx) {                                         // Have we successfully transmitted?
			if (isTransmitter)
			{
				printf("Send:OK");
			}
			if (!isTransmitter) { /*printf("AOK\n");*/ }
		}

		if (fail) {                                       // Have we failed to transmit?
			if (isTransmitter)
			{
				printf("Send:Failed");
			}
			if (!isTransmitter) { printf("AFAIL\n"); }
		}

		if (rx) {                      // Did we receive a message?
			gotData = 1;
		}
		nRF24_ClearIRQFlags();
	}
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
	setStatusLed(0,0,0);
	printf("Error in file %s on line %d\r\n", file, line);
	uint8_t printCount = 0;
	while(1){
		setStatusLed(1,0,0);
		HAL_Delay(100);
		printCount++;
		if(printCount % 5 == 0){
			printf("Error in file %s on line %d\r\n", file, line);
		}
		if(printCount == 20){
			NVIC_SystemReset();
		}
	}
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
