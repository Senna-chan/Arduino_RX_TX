#ifndef __STRUCTS_H
#define __STRUCTS_H

#include "stm32f1xx_hal.h"

#ifdef __cplusplus
extern "C" {
#endif

#define OUTPUTMODE_RC 0

typedef struct
{
	uint8_t outputMode;
	uint8_t outputSet;
	__IO uint32_t* timOutput;
	uint32_t* miscOutput1;
	uint32_t* miscOutput2;
} channelOutputConfig;


#ifdef __cplusplus
}
#endif
#endif
