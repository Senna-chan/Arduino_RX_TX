/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdarg.h>
#include <stdio.h>
#include "structs.h"
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */
/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */
extern UART_HandleTypeDef huart1;
/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */
void _Error_Handler(char *, int);

#define GET_MACRO( _0, _1, NAME, ... ) NAME

#define Error_Handler(...) GET_MACRO( _0, ##__VA_ARGS__, Error_Handler1, Error_Handler0 )()

#define Error_Handler0() _Error_Handler( __FILE__, __LINE__ )

#define Error_Handler1(unused) _Error_Handler( char * file, int line )

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */
void setErrorLed(uint8_t state);
void setOkLed(uint8_t state);
void setBlueLed(uint8_t state);
void setStatusLed(uint8_t R, uint8_t G, uint8_t B);
void common_nRFInit();
void UART_SendChar(char b);
void UART_SendStr(char *string);


/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define USERLED_Pin GPIO_PIN_13
#define USERLED_GPIO_Port GPIOC
#define SLEDR_Pin GPIO_PIN_0
#define SLEDR_GPIO_Port GPIOC
#define SLEDG_Pin GPIO_PIN_1
#define SLEDG_GPIO_Port GPIOC
#define SLEDB_Pin GPIO_PIN_2
#define SLEDB_GPIO_Port GPIOC
#define VIN_SENSE_Pin GPIO_PIN_3
#define VIN_SENSE_GPIO_Port GPIOC
#define CH01_Pin GPIO_PIN_0
#define CH01_GPIO_Port GPIOA
#define CH02_Pin GPIO_PIN_1
#define CH02_GPIO_Port GPIOA
#define CH03_Pin GPIO_PIN_2
#define CH03_GPIO_Port GPIOA
#define CH04_Pin GPIO_PIN_3
#define CH04_GPIO_Port GPIOA
#define CH05_Pin GPIO_PIN_6
#define CH05_GPIO_Port GPIOA
#define CH06_Pin GPIO_PIN_7
#define CH06_GPIO_Port GPIOA
#define DAC2_CH12_Pin GPIO_PIN_4
#define DAC2_CH12_GPIO_Port GPIOC
#define DAC1_CH11_Pin GPIO_PIN_5
#define DAC1_CH11_GPIO_Port GPIOC
#define CH07_Pin GPIO_PIN_0
#define CH07_GPIO_Port GPIOB
#define CH08_Pin GPIO_PIN_1
#define CH08_GPIO_Port GPIOB
#define CH09_Pin GPIO_PIN_10
#define CH09_GPIO_Port GPIOB
#define CH10_Pin GPIO_PIN_11
#define CH10_GPIO_Port GPIOB
#define nRF_CSN_Pin GPIO_PIN_12
#define nRF_CSN_GPIO_Port GPIOB
#define CH11_Pin GPIO_PIN_6
#define CH11_GPIO_Port GPIOC
#define CH12_Pin GPIO_PIN_7
#define CH12_GPIO_Port GPIOC
#define CH13_Pin GPIO_PIN_8
#define CH13_GPIO_Port GPIOC
#define CH14_Pin GPIO_PIN_9
#define CH14_GPIO_Port GPIOC
#define CH15_Pin GPIO_PIN_8
#define CH15_GPIO_Port GPIOA
#define CH16_Pin GPIO_PIN_15
#define CH16_GPIO_Port GPIOA
#define CUSTOM_TX_Pin GPIO_PIN_10
#define CUSTOM_TX_GPIO_Port GPIOC
#define CUSTOM_RX_Pin GPIO_PIN_11
#define CUSTOM_RX_GPIO_Port GPIOC
#define SBUS_TX_Pin GPIO_PIN_12
#define SBUS_TX_GPIO_Port GPIOC
#define SBUS_RX_Pin GPIO_PIN_2
#define SBUS_RX_GPIO_Port GPIOD
#define CH16B3_Pin GPIO_PIN_3
#define CH16B3_GPIO_Port GPIOB
#define nRF_IRQ_Pin GPIO_PIN_4
#define nRF_IRQ_GPIO_Port GPIOB
#define nRF_IRQ_EXTI_IRQn EXTI4_IRQn
#define nRF_CE_Pin GPIO_PIN_5
#define nRF_CE_GPIO_Port GPIOB
#define CH17_Pin GPIO_PIN_6
#define CH17_GPIO_Port GPIOB
#define CH18_Pin GPIO_PIN_7
#define CH18_GPIO_Port GPIOB
/* USER CODE BEGIN Private defines */
//#define Serial huart3
#define nrf_hspi hspi2
#define SerialSBUSCustom huart5
#define isTransmitter 0
#define delay(time) HAL_Delay(time)
/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
